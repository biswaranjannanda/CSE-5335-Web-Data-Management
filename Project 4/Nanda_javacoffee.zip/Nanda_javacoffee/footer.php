		</div>
		<footer>
			<em>
				Copyright &copy; 2018 JavaJam Coffee House
				<br>
				<a href="mailto:biswaranjan@nanda.com">biswaranjan@nanda.com</a>
			</em>
		</footer>
	</body>
</html>
