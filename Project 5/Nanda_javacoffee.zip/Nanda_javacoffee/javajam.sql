CREATE DATABASE  IF NOT EXISTS `javajam` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `javajam`;
-- MySQL dump 10.13  Distrib 5.7.17, for macos10.12 (x86_64)
--
-- Host: localhost    Database: javajam
-- ------------------------------------------------------
-- Server version	5.7.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Job`
--

DROP TABLE IF EXISTS `Job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Job` (
  `JobsId` int(11) NOT NULL AUTO_INCREMENT,
  `Email` varchar(64) NOT NULL,
  `Name` varchar(32) NOT NULL,
  `Experience` varchar(512) NOT NULL,
  PRIMARY KEY (`JobsId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Job`
--

LOCK TABLES `Job` WRITE;
/*!40000 ALTER TABLE `Job` DISABLE KEYS */;
INSERT INTO `Job` VALUES (4,'biswa@nanda.com','biswa','Hero'),(5,'akshay@hero.com','AKshay','3 years Actor'),(6,'hero@akshay.com','Akshay','I am a actor with 3 years of exp.');
/*!40000 ALTER TABLE `Job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Musician`
--

DROP TABLE IF EXISTS `Musician`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Musician` (
  `MusicianId` int(11) NOT NULL,
  `Name` varchar(32) NOT NULL,
  `Musician_Image_URL` varchar(128) NOT NULL,
  PRIMARY KEY (`MusicianId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Musician`
--

LOCK TABLES `Musician` WRITE;
/*!40000 ALTER TABLE `Musician` DISABLE KEYS */;
INSERT INTO `Musician` VALUES (1,'Melanie Morris','images/melaniethumb.jpg'),(2,'Tahoe Greg','images/gregthumb.jpg'),(3,'Katy Perry','images/katythumb.jpg'),(4,'Taylor Swift','images/taylorthumb.jpg');
/*!40000 ALTER TABLE `Musician` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OrderItems`
--

DROP TABLE IF EXISTS `OrderItems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OrderItems` (
  `OrderId` int(11) NOT NULL,
  `ProductId` int(11) NOT NULL,
  `Qty` int(11) NOT NULL,
  `Price` double NOT NULL,
  PRIMARY KEY (`OrderId`,`ProductId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OrderItems`
--

LOCK TABLES `OrderItems` WRITE;
/*!40000 ALTER TABLE `OrderItems` DISABLE KEYS */;
INSERT INTO `OrderItems` VALUES (9,1,1,14.95),(10,3,2,31.9),(10,4,1,25.95),(11,1,2,29.9),(11,2,1,9.95),(11,3,1,15.95),(11,4,1,25.95),(12,1,1,14.95),(15,1,1,14.95),(15,2,1,9.95),(15,3,1,15.95),(15,4,1,25.95);
/*!40000 ALTER TABLE `OrderItems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Orders`
--

DROP TABLE IF EXISTS `Orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Orders` (
  `OrderId` int(10) NOT NULL AUTO_INCREMENT,
  `Name` varchar(32) NOT NULL,
  `EmailId` varchar(64) NOT NULL,
  `Address` varchar(64) NOT NULL,
  `City` varchar(32) NOT NULL,
  `State` varchar(16) NOT NULL,
  `Zip` varchar(8) NOT NULL,
  `Credit_Card` varchar(32) NOT NULL,
  `Month` int(11) NOT NULL,
  `Year` int(11) NOT NULL,
  PRIMARY KEY (`OrderId`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Orders`
--

LOCK TABLES `Orders` WRITE;
/*!40000 ALTER TABLE `Orders` DISABLE KEYS */;
INSERT INTO `Orders` VALUES (12,'Biswa','biswa@nanda.com','415 SUMMIT AVE APT 110','Arlington','TX','76013','4111876756476453',1,2019),(13,'biswa','biswa.nanda@mavs.uta.edu','415 SUMMIT AVE APT 110','Arlington','TX','76013','4111876756476453',1,2019),(14,'biswa','biswa.nanda@mavs.uta.edu','415 SUMMIT AVE APT 110','Arlington','TX','76013','4111876756476453',1,2019),(15,'Akshay','akshay@hero.com','912 Greek Row Dr Apt 130','Arllington','CA','76101','4111876756476453',9,2022);
/*!40000 ALTER TABLE `Orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Performance`
--

DROP TABLE IF EXISTS `Performance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Performance` (
  `PerformanceId` int(11) NOT NULL,
  `MusicianId` int(11) NOT NULL,
  `Month_Year` varchar(16) DEFAULT NULL,
  `Description` varchar(256) NOT NULL,
  PRIMARY KEY (`PerformanceId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Performance`
--

LOCK TABLES `Performance` WRITE;
/*!40000 ALTER TABLE `Performance` DISABLE KEYS */;
INSERT INTO `Performance` VALUES (1,1,'January-2018','Melanie Morris entertains with her melodic folk style.'),(2,2,'February-2018','Tahoe Greg is back from his tour. New Songs. New Stories.'),(3,3,'March-2018','Katy Perry tickets and all other Concert tickets on StubHub! Check out Katy Perry Tour Dates and buy your Katy Perry Concert ticket today.'),(4,4,'April-2018','The official Taylor Swift reputation Stadium Tour is available now! Skip the long lines at the venues and show. Buy tickets from Ticketmaster!');
/*!40000 ALTER TABLE `Performance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Product`
--

DROP TABLE IF EXISTS `Product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Product` (
  `ProductId` int(11) NOT NULL,
  `Name` varchar(32) NOT NULL,
  `Description` varchar(128) NOT NULL,
  `Product_Image_URL` varchar(64) NOT NULL,
  `Price` double DEFAULT NULL,
  PRIMARY KEY (`ProductId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Product`
--

LOCK TABLES `Product` WRITE;
/*!40000 ALTER TABLE `Product` DISABLE KEYS */;
INSERT INTO `Product` VALUES (1,'Shirt','JavaJam shirts are comfortable to wear to school and around town. 100% cotton. XL only.','images/javashirt.jpg',14.95),(2,'Mug','JavaJam mugs carry a full load of caffeine (12 oz.) to jump-start your morning.','images/javamug.jpg',9.95),(3,'Travel Mug','JavaJam Traveller Mug are comfortable to take anywhere you roam around. Easy to travel with.','images/javatravelmug.jpg',10.95),(4,'Coffee Maker','JavaJam Coffee Maker is a single-serve coffeemaker technology often allows the choice of cup size and brew strength, and deliver','images/coffeemaker.jpg',22.95);
/*!40000 ALTER TABLE `Product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'javajam'
--

--
-- Dumping routines for database 'javajam'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-04-22 23:43:15
