<html>
  <head>
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel='stylesheet' type='text/css' href='/Nanda_javacoffee/css/javacoffee.css'>
  </head>
  <body>
    <div id='wrapper'>
      <div id='sidebar' class='column'>
        <nav role="navigation">
          <div id='logo'></div>
          <ul class='menu'>
            <li class = 'menu-li'><a href="<?php echo base_url(); ?>home">Home</a></li>
            <li class = 'menu-li'><a href="<?php echo base_url(); ?>menu">Menu</a></li>
            <li class = 'menu-li'><a href="<?php echo base_url(); ?>music">Music</a></li>
            <li class = 'menu-li'><a href="<?php echo base_url(); ?>jobs">Jobs</a></li>
            <li class = 'menu-li'><a href="<?php echo base_url(); ?>gear">Gear</a></li>
            <li class = 'menu-li'><a href="<?php echo base_url(); ?>cart">Cart</a></li>
            <li class = 'menu-li'><a href="<?php echo base_url(); ?>place_your_order">Order</a></li>
          </ul>
        </nav>
      </div>
