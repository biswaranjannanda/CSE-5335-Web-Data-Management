<div id='main' class = 'column'>
  <h1>JavaJam Coffee House</h1>
  <div id='coffeebar'></div>
    <div id='content'>
      <h2>Coffee at JavaJam</h2>
      Indulge in our locally roasted free-trade coffee and enjoy the aroma, the smooth taste, and the caffeine!
      Join our Mug Club and get a 10% discount on each cup of coffee you purchase -ask the barista for details.
      <br />
      <br />
      <table>
        <tr class='menu-row'>
          <td class='menu-item'><b>Just Java</b></td>
          <td class='menu--desc'>Regular house blend, decaffeinated coffee, or flavor of the day.<br />
              Endless Cup $2.00</td>
        </tr>
        <tr class='menu-row'>
          <td class='menu-item'><b>Cafe au Lait</b></td>
          <td class='menu-desc'>House blended coffee infused into a smooth, steamed milk.<br />
              Single $2.00 Double $3.00</td>
        </tr>
        <tr class='menu-row'>
          <td class='menu-item'><b>Iced Cappuccino</b></td>
          <td class='menu-desc'>Sweetened espresso blended with icy-cold milk and served in a chilled glass.<br />
              Single $4.75 Double $5.75</td>
        </tr>
      </table>
      <br />
    </div>
</div>
