<div id='main' class = 'column'>
  <h1>JavaJam Coffee House</h1>
  <div id='content'>
    <h2>Submission Successful</h2>
    Thank you for submitting your form/order!
    <br /><br /><br /><br /><br />
  </div>
</div>
