<div id='main' class = 'column'>
  <h1>JavaJam Coffee House</h1>
  <div id='guitar'></div>
    <div id='content'>
      <h2>Music at JavaJam</h2>
      The first Friday night each month at JavaJam is a special night.
      Join us from 8 pm to 11 pm for some music you won't want to miss!
    </div>
    <?php
      foreach($musicians as $row) {
        $performanceMonth = strtoupper(substr($row['Month_Year'], 0, strpos($row['Month_Year'], '-')));
        echo "<h3>".$performanceMonth."</h3>\n";
        echo "<div class='musician'>\n";
        echo "<img src=".$row['Musician_Image_URL']." class='musician_image'>\n";
        echo $row['Description']."\n";
        echo "</div><br />";
      }
     ?>

</div>
