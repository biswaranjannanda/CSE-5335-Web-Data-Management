<div id='main' class = 'column'>
  <h1>JavaJam Coffee House</h1>
  <div id='content'>
    <center>

      <?php
        $this->load->view('cart_contents');
      ?>

      <br />
      <table>
        <td style='text-align: right; width: 50%;'>
          <form action="place_your_order">
            <input type="submit" value="Place Order" />
          </form>
        </td>
        <td style='text-align: left; width: 50%;'>
          <form action="gear">
            <input type="submit" value="Continue Shopping" />
          </form>
        </td>
    </table>
    </center>
  </div>
</div>
