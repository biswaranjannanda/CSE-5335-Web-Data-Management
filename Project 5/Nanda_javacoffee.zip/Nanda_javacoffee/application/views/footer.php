<footer>
  <i>Copyright &copy; 2018 JavaJam Coffee House</i><br />
  <a href='mailto:biswaranjan@nanda.com'>biswaranjan@nanda.com</a>
</footer>
</div>
</body>
</html>
