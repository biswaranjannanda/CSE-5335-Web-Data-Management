<!-- Shopping Cart -->
<h2>Shopping Cart</h2>
<table>
  <tr class='menu-row'>
    <th>Description</th>
    <th>Quantity</th>
    <th>Price</th>
  </tr>
  <?php

    $names=array('', '', '', '');
    $prices=array(0.0, 0.0, 0.0, 0.0);

    $i=0;
    foreach($gear as $row) {
      $names[$i] = $row['Name'];
      $prices[$i] = $row['Price'];
      $i++;
    }

    $total=0;

    if(!isset($_SESSION['cart'])) {
      $_SESSION['cart']=array(0, 0, 0, 0);
    }
    for($i=1; $i<=4; $i++) {
      if(isset($_POST['desc'.$i])) {
        $_SESSION['cart'][$i-1]++;
      }
      if($_SESSION['cart'][$i-1]>0) {


        echo "<tr class='menu-row'>\n";
        echo "<td>".$names[$i-1]."</td>";
        echo "<td>".$_SESSION['cart'][$i-1]."</td>";
        echo "<td>$".$prices[$i-1]."</td>\n";
        echo "</tr>";
        $total += $_SESSION['cart'][$i-1]*$prices[$i-1];
      }
    }

    echo "<tr class='menu-row'>\n";
    echo "<td></td>";
    echo "<td>Total:</td>";
    echo "<td>$".money_format('%i',$total)."</td>";
    echo "</tr>";
   ?>
</table>
<!-- End Shopping Cart -->
