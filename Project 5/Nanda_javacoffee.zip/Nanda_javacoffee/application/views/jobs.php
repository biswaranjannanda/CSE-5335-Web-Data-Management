<div id='main' class = 'column'>
  <h1>JavaJam Coffee House</h1>
    <div id='content'>
      <h2>Jobs at JavaJam</h2>
      Want to work at JavaJam? Fill out the following form to start your application. Required fields
      are marked with an asterisk (*).
      <br /><br />
      <?php
        echo form_open('jobs');
        echo "<span class='error-msg'>".form_error('txtName')."</span><label>*Name</label>".form_input('txtName')."<br />";
        echo "<span class='error-msg'>".form_error('txtEmail')."</span><label>*Email</label>".form_input('txtEmail')."<br />";
        echo "<span class='error-msg'>".form_error('txtaExperience')."</span><label style='vertical-align: top;'>*Experience</label>".form_textarea('txtaExperience')."<br /><br />";
        echo form_submit('submitButton', 'Apply Now');
        echo form_close();
       ?>
      <br /><br />
    </div>
</div>
