<div id='main' class = 'column'>
  <h1>JavaJam Coffee House</h1>
  <div id='couch'></div>
    <div id='content'>
      <h2>JavaJam Gear</h2>
      JavaJam gear not only looks good, it's good to your wallet too.<br />
      Get a 10% discount when you wear a JavaJam shirt or bring in your JavaJam mug!<br />
    </div>
    <table>
      <?php
        for($i=1; $i<=4; $i++) {
          $row = $gear[$i-1];
          echo "<tr>\n";
          echo "<td><img src=".$row['Product_Image_URL']." width='150px' height='150px'></td>";
          echo "<td class='gear-item'>".$row['Description']."&nbsp;$".$row['Price']."<br /><br />";
          echo form_open('cart');
          echo form_hidden('desc'.$i, $row['Name']);
          echo form_hidden('cost'.$i, $row['Price']);
          echo form_submit('submit', 'Add to Cart');
          echo form_close();
          echo "</td>\n";
          echo "</tr>";
        }
       ?>
    </table>

</div>
