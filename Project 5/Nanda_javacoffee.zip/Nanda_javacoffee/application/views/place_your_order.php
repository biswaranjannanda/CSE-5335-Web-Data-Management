<div id='main' class = 'column'>
  <h1>JavaJam Coffee House</h1>
  <div id='content'>
    <center>
      <?php
        $this->load->view('cart_contents');
       ?>
      <br />

      <?php

        $stateArray=array(
                      	'AL'=>'ALABAMA',
                      	'AK'=>'ALASKA',
                      	'AZ'=>'ARIZONA',
                      	'AR'=>'ARKANSAS',
                      	'CA'=>'CALIFORNIA',
                      	'CO'=>'COLORADO',
                      	'CT'=>'CONNECTICUT',
                      	'DE'=>'DELAWARE',
                      	'DC'=>'DISTRICT OF COLUMBIA',
                      	'FL'=>'FLORIDA',
                      	'GA'=>'GEORGIA',
                      	'HI'=>'HAWAII',
                      	'ID'=>'IDAHO',
                      	'IL'=>'ILLINOIS',
                      	'IN'=>'INDIANA',
                      	'IA'=>'IOWA',
                      	'KS'=>'KANSAS',
                      	'KY'=>'KENTUCKY',
                      	'LA'=>'LOUISIANA',
                      	'ME'=>'MAINE',
                      	'MD'=>'MARYLAND',
                      	'MA'=>'MASSACHUSETTS',
                      	'MI'=>'MICHIGAN',
                      	'MN'=>'MINNESOTA',
                      	'MS'=>'MISSISSIPPI',
                      	'MO'=>'MISSOURI',
                      	'MT'=>'MONTANA',
                      	'NE'=>'NEBRASKA',
                      	'NV'=>'NEVADA',
                      	'NH'=>'NEW HAMPSHIRE',
                      	'NJ'=>'NEW JERSEY',
                      	'NM'=>'NEW MEXICO',
                      	'NY'=>'NEW YORK',
                      	'NC'=>'NORTH CAROLINA',
                      	'ND'=>'NORTH DAKOTA',
                      	'OH'=>'OHIO',
                      	'OK'=>'OKLAHOMA',
                      	'OR'=>'OREGON',
                      	'PA'=>'PENNSYLVANIA',
                      	'RI'=>'RHODE ISLAND',
                      	'SC'=>'SOUTH CAROLINA',
                      	'SD'=>'SOUTH DAKOTA',
                      	'TN'=>'TENNESSEE',
                      	'TX'=>'TEXAS',
                      	'UT'=>'UTAH',
                      	'VT'=>'VERMONT',
                      	'VA'=>'VIRGINIA',
                      	'WA'=>'WASHINGTON',
                      	'WV'=>'WEST VIRGINIA',
                      	'WI'=>'WISCONSIN',
                      	'WY'=>'WYOMING');

        $monthArray = array('01'=>'JAN',
                            '02'=>'FEB',
                            '03'=>'MAR',
                            '04'=>'APR',
                            '05'=>'MAY',
                            '06'=>'JUN',
                            '07'=>'JUL',
                            '08'=>'AUG',
                            '09'=>'SEP',
                            '10'=>'OCT',
                            '11'=>'NOV',
                            '12'=>'DEC');


        echo form_open('place_your_order');
          echo form_fieldset('Fill Details');
            echo "<table id='ordertable'>\n";
              echo "<tr>\n";
                echo "<td><label>Name</label></td>\n";
                echo "<td><span class='error-msg'".form_error('name')."</span>".form_input('name')."</td>\n";
                echo "<td></td><td></td>\n";
              echo "</tr>\n";
              echo "<tr>\n";
                echo "<td><label>Email</label></td>\n";
                echo "<td><span class='error-msg'".form_error('email')."</span>".form_input('email')."</td>\n";
                echo "<td></td><td></td>\n";
              echo "</tr>\n";
              echo "<tr>\n";
                echo "<td><label>Address</label></td>\n";
                echo "<td><span class='error-msg'".form_error('address')."</span>".form_input('address')."</td>\n";
                echo "<td></td><td></td>\n";
              echo "</tr>\n";
              echo "<tr>\n";
                echo "<td><label>City</label></td>\n";
                echo "<td><span class='error-msg'".form_error('city')."</span>".form_input('city')."</td>\n";
                echo "<td></td><td></td>\n";
              echo "</tr>\n";
              echo "<tr>\n";
                echo "<td><label>State</label></td>\n";
                echo "<td>".form_dropdown('state', $stateArray)."</td>\n";
                echo "<td><label>Zip</label></td>";
                echo "<td><span class='error-msg'".form_error('zip')."</span>".form_input('zip')."</td>\n";
              echo "</tr>\n";
              echo "<tr>\n";
                echo "<td><label>Credit Card</label></td>\n";
                echo "<td><span class='error-msg'".form_error('cc')."</span>".form_input('cc')."</td>\n";
                echo "<td></td><td></td>\n";
              echo "</tr>\n";
              echo "<tr>\n";
                echo "<td><label>Exp Month</label></td>\n";
                echo "<td>".form_dropdown('ccmo', $monthArray)."</td>\n";
                echo "<td><label>Year</label></td>";
                echo "<td><span class='error-msg'".form_error('ccyr')."</span>".form_input('ccyr')."</td>\n";
              echo "</tr>\n";
              echo "<tr>\n";
                echo "<td></td>\n";
                echo "<td>".form_submit('submit', 'Order Now')."</td>\n";
                echo "<td></td><td></td>\n";
              echo "</tr>\n";
            echo "</table>";
          echo form_fieldset_close();
        echo form_close();
       ?>
    </center>
  </div>
</div>
