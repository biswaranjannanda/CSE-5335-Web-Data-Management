<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Place_Your_Order extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
    $data['gear']=$this->place_your_order_model->get_gear();
    $this->load->library('session');
    $this->load->helper('form');
    $this->load->library('form_validation');

    $this->form_validation->set_rules('name', 'Name', 'required');
    $this->form_validation->set_rules('email', 'E-mail', 'required|valid_email');
    $this->form_validation->set_rules('address', 'Address', 'required');
    $this->form_validation->set_rules('city', 'City', 'required');
    $this->form_validation->set_rules('zip', 'Zip Code', 'required|exact_length[5]|numeric');
    $this->form_validation->set_rules('cc', 'Credit Card', 'required|exact_length[16]|numeric');
    $this->form_validation->set_rules('ccyr', 'Expiration Year', 'required|exact_length[4]|numeric');

    if ($this->form_validation->run() == FALSE) {
      $this->load->view('header');
      $this->load->view('place_your_order', $data);
  		$this->load->view('footer');
    } else {

      $orderArray=array(
                        'Name'=>$this->input->post('name'),
                        'EmailId'=>$this->input->post('email'),
                        'Address'=>$this->input->post('address'),
                        'City'=>$this->input->post('city'),
                        'State'=>$this->input->post('state'),
                        'Zip'=>$this->input->post('zip'),
                        'Credit_Card'=>$this->input->post('cc'),
                        'Month'=>$this->input->post('ccmo'),
                        'Year'=>$this->input->post('ccyr')
                        );

      $orderId=$this->place_your_order_model->insert_order($orderArray);
			$this->place_your_order_model->insert_order_items($orderId);
      $_SESSION['cart']=array(0, 0, 0, 0);
      $this->load->view('header');
      $this->load->view('form_success');
      $this->load->view('footer');
    }


	}
}
