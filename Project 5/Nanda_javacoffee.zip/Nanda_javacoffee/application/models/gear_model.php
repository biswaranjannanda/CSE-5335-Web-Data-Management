<?php
  class gear_model extends CI_Model {
    public function __construct() {
      $this->load->database();
      $this->load->helper('form');
    }

    public function get_gear() {
      $query=$this->db->query("SELECT * FROM Product;");
      return $query->result_array();
    }

  }

 ?>
