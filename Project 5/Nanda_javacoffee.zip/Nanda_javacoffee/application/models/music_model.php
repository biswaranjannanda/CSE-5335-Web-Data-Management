<?php
  class music_model extends CI_Model {
    public function __construct() {
      $this->load->database();
    }

    public function get_musicians() {
      $query=$this->db->query("SELECT M.Musician_Image_URL, P.Month_Year, P.Description FROM Musician as M, Performance as P WHERE M.MusicianId=P.MusicianId");
      return $query->result_array();
    }

  }

 ?>
