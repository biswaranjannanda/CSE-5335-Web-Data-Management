<?php
  class place_your_order_model extends CI_Model {
    public function __construct() {
      $this->load->database();
    }

    public function get_gear() {
      $query=$this->db->query("SELECT * FROM Product;");
      return $query->result_array();
    }



    public function insert_order($orderArray) {
      $this->db->insert('Orders', $orderArray);
      return $this->db->insert_id();
    }

    public function insert_order_items($orderId) {
      $priceArray = array(14.95, 9.95, 15.95, 25.95);
      for($i=1; $i<=4; $i++) {
        $qty=$_SESSION['cart'][$i-1];
        if($qty > 0) {
          $this->db->insert('OrderItems', array('OrderId' =>$orderId,
                                                  'ProductId'=>$i,
                                                  'Qty'=>$qty,
                                                  'Price'=>$priceArray[$i-1]*$qty));
        }

      }
    }

  }

 ?>
