<?php
  class jobs_model extends CI_Model {
    public function __construct() {
      $this->load->database();
    }

    public function insert_jobs($jobsArray) {
      $this->db->insert('Job', $jobsArray);
      return $this->db->insert_id();
    }

  }

 ?>
